from __future__ import annotations

from abc import ABC, abstractmethod
from collections import deque
from typing import Callable, Deque, Dict, List, Tuple
import heapq
import itertools
import math
import random

EPS = 1e-9

from .process import Task


class Policy(ABC):
    """Base scheduling policy with hooks for arrivals and dispatch."""

    name: str = "policy"
    preemptive: bool = False

    def __init__(self, **_: float) -> None:
        self.ready: Deque[Task] = deque()

    def on_arrival(self, task: Task, t: float | None = None) -> None:
        self.ready.append(task)

    def has_ready(self) -> bool:
        return bool(self.ready)

    @abstractmethod
    def pick_next(self, t: float, ready, running: Task | None) -> Task:
        raise NotImplementedError

    def time_slice(self, t: float, task: Task) -> float:
        return task.remaining

    def on_run_completed(self, task: Task, duration: float) -> None:
        pass

    def on_task_done(self, task: Task, t: float) -> None:
        pass

    def on_preempted(self, task: Task, t: float) -> None:
        self.on_arrival(task, t)

    def ready_state(self) -> List[str]:
        ready_attr = getattr(self, "ready", None)
        if ready_attr is None:
            return []
        return [task.pid for task in list(ready_attr)]


class FirstComeFirstServe(Policy):
    name = "fcfs"
    preemptive = False

    def __init__(self, **_: float) -> None:
        super().__init__()
        self.ready: Deque[Task] = deque()

    def on_arrival(self, task: Task, t: float | None = None) -> None:
        self.ready.append(task)

    def pick_next(self, t: float, ready, running: Task | None) -> Task:
        return self.ready.popleft()


class RoundRobin(Policy):
    name = "rr"
    preemptive = True

    def __init__(self, quantum: float = 4.0, **_: float) -> None:
        super().__init__()
        self.quantum = quantum
        self.ready: Deque[Task] = deque()

    def on_arrival(self, task: Task, t: float | None = None) -> None:
        self.ready.append(task)

    def pick_next(self, t: float, ready, running: Task | None) -> Task:
        return self.ready.popleft()

    def time_slice(self, t: float, task: Task) -> float:
        return min(self.quantum, task.remaining)

    def on_preempted(self, task: Task, t: float) -> None:
        self.ready.append(task)


class ShortestJobFirst(Policy):
    name = "sjf"
    preemptive = False

    def __init__(self, **_: float) -> None:
        super().__init__()
        self.ready: List[Tuple[float, int, Task]] = []
        self._counter = itertools.count()

    def on_arrival(self, task: Task, t: float | None = None) -> None:
        heapq.heappush(self.ready, (task.remaining, next(self._counter), task))

    def has_ready(self) -> bool:
        return bool(self.ready)

    def pick_next(self, t: float, ready, running: Task | None) -> Task:
        _, _, task = heapq.heappop(self.ready)
        return task

    def ready_state(self) -> List[str]:
        return [entry[2].pid for entry in self.ready]


class CFSLite(Policy):
    name = "cfs_lite"
    preemptive = True

    def __init__(self, slice_ms: float = 3.0, **_: float) -> None:
        super().__init__()
        self.slice_ms = slice_ms
        self.ready_list: List[Task] = []

    def _min_vruntime(self) -> float:
        if not self.ready_list:
            return 0.0
        return min(task.vruntime for task in self.ready_list)

    def on_arrival(self, task: Task, t: float | None = None) -> None:
        if task.vruntime == 0.0 and self.ready_list:
            task.vruntime = self._min_vruntime()
        self.ready_list.append(task)

    def has_ready(self) -> bool:
        return bool(self.ready_list)

    def pick_next(self, t: float, ready, running: Task | None) -> Task:
        idx = min(range(len(self.ready_list)), key=lambda i: self.ready_list[i].vruntime)
        return self.ready_list.pop(idx)

    def time_slice(self, t: float, task: Task) -> float:
        return min(self.slice_ms, task.remaining)

    def on_run_completed(self, task: Task, duration: float) -> None:
        weight = max(1, task.weight)
        task.vruntime += duration * (1024.0 / weight)

    def on_preempted(self, task: Task, t: float) -> None:
        self.on_arrival(task, t)

    def ready_state(self) -> List[str]:
        return [task.pid for task in self.ready_list]


class OracleSJF(Policy):
    name = "oracle_sjf"
    preemptive = False

    def __init__(self, **_: float) -> None:
        super().__init__()
        self.ready: List[Tuple[float, int, Task]] = []
        self._counter = itertools.count()

    def on_arrival(self, task: Task, t: float | None = None) -> None:
        heapq.heappush(self.ready, (task.remaining, next(self._counter), task))

    def has_ready(self) -> bool:
        return bool(self.ready)

    def pick_next(self, t: float, ready, running: Task | None) -> Task:
        _, _, task = heapq.heappop(self.ready)
        return task

    def ready_state(self) -> List[str]:
        return [entry[2].pid for entry in self.ready]


def noisy_predictor(sigma: float = 0.25, seed: int | None = None) -> Callable[[Task], float]:
    rng = random.Random()
    if seed is not None:
        rng.seed(seed)

    def _predict(task: Task) -> float:
        noise = math.exp(rng.gauss(0.0, sigma))
        burst = max(task.burst, EPS)
        return max(EPS, burst * noise)

    return _predict


class PredictedSJF(Policy):
    name = "predicted_sjf"
    preemptive = False

    def __init__(
        self,
        predictor: Callable[[Task], float] | None = None,
        sigma: float = 0.25,
        seed: int | None = None,
        **_: float,
    ) -> None:
        super().__init__()
        self.ready: List[Tuple[float, int, Task]] = []
        self._counter = itertools.count()
        self.predict_fn = predictor or noisy_predictor(sigma, seed)

    def on_arrival(self, task: Task, t: float | None = None) -> None:
        if task.predicted is None:
            task.predicted = float(self.predict_fn(task))
        prediction = max(EPS, task.predicted)
        heapq.heappush(self.ready, (prediction, next(self._counter), task))

    def has_ready(self) -> bool:
        return bool(self.ready)

    def pick_next(self, t: float, ready, running: Task | None) -> Task:
        _, _, task = heapq.heappop(self.ready)
        return task

    def ready_state(self) -> List[str]:
        return [entry[2].pid for entry in self.ready]


POLICIES: Dict[str, type[Policy]] = {
    FirstComeFirstServe.name: FirstComeFirstServe,
    RoundRobin.name: RoundRobin,
    ShortestJobFirst.name: ShortestJobFirst,
    CFSLite.name: CFSLite,
    OracleSJF.name: OracleSJF,
    PredictedSJF.name: PredictedSJF,
}
