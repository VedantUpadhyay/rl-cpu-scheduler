from __future__ import annotations

from typing import Dict, List
import math

from .process import Task

MetricsDict = Dict[str, float]


def _nearest_rank(values: List[float], percentile: float) -> float:
    if not values:
        return 0.0
    sorted_vals = sorted(values)
    n = len(sorted_vals)
    # Nearest-rank uses 1-based ranks and ceil(p/100 * n)
    rank = max(1, math.ceil(percentile / 100.0 * n))
    return sorted_vals[min(rank - 1, n - 1)]


def compute_metrics(tasks: List[Task], context_switches: int, makespan: float) -> MetricsDict:
    if not tasks:
        return {
            "completed_tasks": 0,
            "avg_wait": 0.0,
            "avg_turn": 0.0,
            "p95_wait": 0.0,
            "p95_turn": 0.0,
            "avg_response": 0.0,
            "dispatches": context_switches,
            "makespan": makespan,
        }

    waits: List[float] = []
    turns: List[float] = []
    responses: List[float] = []

    for task in tasks:
        start = task.start if task.start is not None else task.arrival
        finish = task.finish if task.finish is not None else start
        wait = start - task.arrival
        turnaround = finish - task.arrival
        response = start - task.arrival
        waits.append(wait)
        turns.append(turnaround)
        responses.append(response)

    n = len(tasks)
    metrics: MetricsDict = {
        "completed_tasks": n,
        "avg_wait": sum(waits) / n,
        "avg_turn": sum(turns) / n,
        "p95_wait": _nearest_rank(waits, 95),
        "p95_turn": _nearest_rank(turns, 95),
        "avg_response": sum(responses) / n,
        "dispatches": context_switches,
        "makespan": makespan,
    }
    return metrics


_METRIC_LABELS = [
    ("avg_wait", "Avg Wait"),
    ("avg_turn", "Avg Turn"),
    ("p95_wait", "P95 Wait"),
    ("p95_turn", "P95 Turn"),
    ("avg_response", "Avg Resp"),
    ("dispatches", "Dispatches"),
    ("makespan", "Makespan"),
]


def format_metrics(metrics: MetricsDict) -> str:
    """Return a human-friendly multiline string for a metrics dict."""
    lines = []
    for key, label in _METRIC_LABELS:
        value = metrics.get(key, 0.0)
        if key in {"dispatches"}:
            display = f"{int(round(value))}"
        else:
            display = f"{value:.2f}"
        lines.append(f"{label:>12}: {display:>10}")
    lines.append(f"{'Tasks':>12}: {int(round(metrics.get('completed_tasks', 0))):>10}")
    return "\n".join(lines)
