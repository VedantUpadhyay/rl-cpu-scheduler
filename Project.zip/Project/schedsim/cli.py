from __future__ import annotations

import argparse
import json
from typing import Dict, List

from .io import TestcaseError, load_testcase
from .process import Workload
from .simulator import Simulator
from .metrics import format_metrics

POLICY_CHOICES = {
    "fcfs": "fcfs",
    "rr": "rr",
    "sjf": "sjf",
    "predicted_sjf": "predicted_sjf",
    "cfs": "cfs_lite",
    "oracle_sjf": "oracle_sjf",
}


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="schedsim", description="CPU scheduling simulator")
    subparsers = parser.add_subparsers(dest="command", required=True)

    run_parser = subparsers.add_parser("run", help="Run a workload JSON with a scheduling policy")
    run_parser.add_argument("testcase", help="Path to workload JSON file")
    run_parser.add_argument(
        "--policy",
        choices=sorted(POLICY_CHOICES.keys()),
        default="fcfs",
        help="Scheduling policy to use",
    )
    run_parser.add_argument("--quantum", type=float, help="RR time quantum")
    run_parser.add_argument("--slice", type=float, help="CFS slice length")
    run_parser.add_argument("--sigma", type=float, default=0.25, help="Noise sigma for predicted SJF")
    run_parser.add_argument("--seed", type=int, help="Random seed for stochastic policies")
    run_parser.add_argument("--format", choices=["text", "json"], default="text", help="Output format for metrics")
    run_parser.add_argument("--timeline", action="store_true", help="Print per-task start/finish")
    run_parser.add_argument(
        "--print-timeline",
        action="store_true",
        help="Print event timeline with time, running pid, and ready pids",
    )
    return parser


def _policy_kwargs(policy_key: str, args: argparse.Namespace) -> Dict:
    if policy_key == "rr":
        return {"quantum": args.quantum if args.quantum is not None else 4.0}
    if policy_key == "cfs_lite":
        return {"slice_ms": args.slice if args.slice is not None else 3.0}
    if policy_key == "predicted_sjf":
        return {"sigma": args.sigma, "seed": args.seed}
    return {}


def _print_task_summary(tasks: List) -> None:
    print("\nPer-task timeline:")
    for task in sorted(tasks, key=lambda t: (t.start if t.start is not None else t.arrival)):
        start = task.start if task.start is not None else -1
        finish = task.finish if task.finish is not None else -1
        print(f"  {task.pid}: start={start:.2f} finish={finish:.2f} burst={task.burst}")


def _print_event_timeline(timeline: List[Dict[str, object]]) -> None:
    if not timeline:
        return
    print("\nEvent timeline:")
    prev = None
    for entry in timeline:
        key = (entry["time"], entry["running"], tuple(entry["ready"]))
        if key == prev:
            continue
        prev = key
        time = entry["time"]
        running = entry["running"] or "-"
        ready = entry["ready"]
        ready_str = ",".join(ready) if ready else "-"
        print(f"  t={time:>6.2f} | running={running:<4} | ready=[{ready_str}]")


def _normalize_metrics(metrics: Dict[str, float]) -> Dict[str, float]:
    return {
        "avg_waiting": metrics["avg_wait"],
        "p95_waiting": metrics["p95_wait"],
        "avg_turnaround": metrics["avg_turn"],
        "p95_turnaround": metrics["p95_turn"],
        "avg_response": metrics["avg_response"],
        "dispatches": metrics["dispatches"],
        "makespan": metrics["makespan"],
        "completed_tasks": metrics["completed_tasks"],
    }


def handle_run(args: argparse.Namespace) -> int:
    try:
        workload_name, tasks = load_testcase(args.testcase)
    except TestcaseError as exc:
        print(f"error: {exc}")
        return 2

    workload = Workload(name=workload_name, tasks=tasks)
    simulator = Simulator(workload)

    policy_key = POLICY_CHOICES[args.policy]
    kwargs = _policy_kwargs(policy_key, args)

    metrics, completed, timeline = simulator.run(policy_key, **kwargs)
    norm_metrics = _normalize_metrics(metrics)

    if args.format == "json":
        payload = {
            "workload": workload.name,
            "policy": policy_key,
            "metrics": norm_metrics,
        }
        print(json.dumps(payload))
        return 0

    print(f"Workload: {workload.name}")
    print(f"Policy: {args.policy} ({policy_key})")
    print(format_metrics(metrics))

    if args.timeline:
        _print_task_summary(completed)
    if args.print_timeline:
        _print_event_timeline(timeline)
    return 0


def main(argv: List[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    if args.command == "run":
        return handle_run(args)
    parser.error("unknown command")
    return 2
