from schedsim.process import Task


def test_task_remaining_equals_burst() -> None:
    task = Task(pid="demo", arrival=0, burst=7, weight=1)
    assert task.remaining == task.burst


if __name__ == "__main__":
    test_task_remaining_equals_burst()
    print("Task invariant OK")
