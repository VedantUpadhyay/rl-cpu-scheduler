from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, List


@dataclass
class Task:
    """
    Runtime representation of a schedulable task.

    Fields are intentionally aligned with common OS textbooks so policies can
    reason about arrival/burst information as well as weights/predictions for
    ML-friendly schedulers.
    """

    pid: str
    arrival: int
    burst: int
    remaining: int = field(init=False)
    start: int | None = None
    finish: int | None = None
    vruntime: float = 0.0
    weight: int = 1024
    predicted: float | None = None

    def __post_init__(self) -> None:
        if self.arrival < 0:
            raise ValueError("arrival must be >= 0")
        if self.burst <= 0:
            raise ValueError("burst must be > 0")
        self.remaining = self.burst
        self._waiting_time: float = 0.0
        self._last_ready: float | None = None

    @classmethod
    def from_spec(
        cls,
        pid: str,
        arrival: int,
        burst: int,
        *,
        weight: int = 1024,
        predicted: float | None = None,
    ) -> "Task":
        return cls(
            pid=pid,
            arrival=arrival,
            burst=burst,
            weight=weight,
            predicted=predicted,
        )

    def clone(self) -> "Task":
        return Task.from_spec(
            pid=self.pid,
            arrival=self.arrival,
            burst=self.burst,
            weight=self.weight,
            predicted=self.predicted,
        )

    def mark_ready(self, now: float) -> None:
        self._last_ready = now

    def mark_dispatch(self, now: float) -> None:
        if self._last_ready is not None:
            self._waiting_time += max(0.0, now - self._last_ready)
        if self.start is None:
            self.start = now

    def mark_complete(self, now: float) -> None:
        self.finish = now
        self.remaining = 0

    @property
    def waiting_time(self) -> float:
        return self._waiting_time

    @property
    def turnaround_time(self) -> float:
        if self.finish is None:
            return 0.0
        return self.finish - self.arrival


@dataclass
class Workload:
    name: str
    tasks: List[Task]
    metadata: Dict[str, Any] = field(default_factory=dict)

    def fresh_tasks(self) -> List[Task]:
        return [task.clone() for task in self.tasks]
