from __future__ import annotations

import json
from pathlib import Path
from typing import List, Tuple

from .process import Task


class TestcaseError(ValueError):
    pass


def load_testcase(path: str | Path) -> Tuple[str, List[Task]]:
    file_path = Path(path)
    try:
        data = json.loads(file_path.read_text())
    except FileNotFoundError as exc:
        raise TestcaseError(f"Testcase file not found: {file_path}") from exc
    except json.JSONDecodeError as exc:
        raise TestcaseError(f"Invalid JSON in {file_path}") from exc

    tasks_data = data.get("tasks")
    if not isinstance(tasks_data, list):
        raise TestcaseError("Testcase JSON must include a 'tasks' list")

    default_weight = int(data.get("default_weight", 1024))
    parsed: List[Task] = []
    for idx, task_entry in enumerate(tasks_data):
        if not isinstance(task_entry, dict):
            raise TestcaseError(f"Task entry at index {idx} must be an object: {task_entry}")
        try:
            pid = str(task_entry["pid"])
            arrival = int(task_entry["arrival"])
            burst = int(task_entry["burst"])
        except (KeyError, TypeError, ValueError) as exc:
            raise TestcaseError(f"Invalid task entry at index {idx}: {task_entry}") from exc
        weight = int(task_entry.get("weight", default_weight))
        predicted_value = task_entry.get("predicted")
        predicted = float(predicted_value) if predicted_value is not None else None
        parsed.append(
            Task.from_spec(
                pid=pid,
                arrival=arrival,
                burst=burst,
                weight=weight,
                predicted=predicted,
            )
        )

    workload_name = str(data.get("name", file_path.stem))
    return workload_name, parsed
