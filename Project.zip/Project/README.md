# SchedSim

## POC Verification

Run the automated checks before any demo:

```bash
python verify_poc.py
```

Expected successful output:

```
DEMO READY
```
