from __future__ import annotations

from typing import Dict, List, Tuple, Type

from .process import Task, Workload
from .policies import POLICIES, Policy
from .metrics import compute_metrics, MetricsDict

EPS = 1e-9


def simulate(tasks: List[Task], policy: Policy) -> Tuple[List[Task], int, float, List[Dict[str, object]]]:
    """Discrete-event CPU scheduling simulation."""
    if not tasks:
        return [], 0, 0.0, []

    pending = sorted(tasks, key=lambda task: task.arrival)
    total = len(pending)
    completed: List[Task] = []
    future_idx = 0
    t = float(pending[0].arrival)
    start_time = t
    running: Task | None = None
    slice_budget = 0.0
    context_switches = 0
    timeline: List[Dict[str, object]] = []

    def release_arrivals(current_time: float) -> None:
        nonlocal future_idx
        while future_idx < total and pending[future_idx].arrival <= current_time + EPS:
            task = pending[future_idx]
            task.mark_ready(float(task.arrival))
            policy.on_arrival(task, current_time)
            future_idx += 1

    release_arrivals(t)

    def snapshot() -> None:
        ready = policy.ready_state()
        timeline.append(
            {
                "time": t,
                "running": running.pid if running else None,
                "ready": list(ready),
            }
        )

    snapshot()

    while len(completed) < total:
        if running is None:
            if policy.has_ready():
                running = policy.pick_next(t, getattr(policy, "ready", None), running)
                running.mark_dispatch(t)
                context_switches += 1
                slice_budget = max(EPS, policy.time_slice(t, running))
                snapshot()
            else:
                if future_idx < total:
                    t = float(pending[future_idx].arrival)
                    release_arrivals(t)
                    snapshot()
                    continue
                break

        run_amount = min(slice_budget, running.remaining)
        t += run_amount
        running.remaining = max(0.0, running.remaining - run_amount)
        policy.on_run_completed(running, run_amount)
        slice_budget -= run_amount
        release_arrivals(t)
        snapshot()

        if running.remaining <= EPS:
            running.mark_complete(t)
            policy.on_task_done(running, t)
            completed.append(running)
            running = None
            slice_budget = 0.0
        elif slice_budget <= EPS:
            running.mark_ready(t)
            policy.on_preempted(running, t)
            running = None
            slice_budget = 0.0

    makespan = (max((task.finish or t) for task in completed) - start_time) if completed else 0.0
    return completed, context_switches, makespan, timeline


class Simulator:
    def __init__(self, workload: Workload) -> None:
        self.workload = workload

    def available_policies(self) -> Dict[str, Type[Policy]]:
        return dict(POLICIES)

    def run(self, policy_name: str, **policy_kwargs: float) -> Tuple[MetricsDict, List[Task]]:
        if policy_name not in POLICIES:
            raise ValueError(f"Unknown policy '{policy_name}'. Choices: {', '.join(POLICIES)}")
        policy = POLICIES[policy_name](**policy_kwargs)
        tasks = self.workload.fresh_tasks()
        completed, ctx_switches, makespan, timeline = simulate(tasks, policy)
        metrics = compute_metrics(completed, ctx_switches, makespan)
        return metrics, completed, timeline
