#!/usr/bin/env python3
from __future__ import annotations

import json
import subprocess
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, List

from schedsim.io import load_testcase
from schedsim.process import Task
from schedsim.policies import FirstComeFirstServe
from schedsim.simulator import simulate

ROOT = Path(__file__).resolve().parent
PYTHON = sys.executable
EPS = 1e-9


@dataclass
class CommandSpec:
    name: str
    testcase: str
    args: List[str]


COMMAND_SPECS: List[CommandSpec] = [
    CommandSpec("basic_fcfs", "tests/basic.json", ["--policy", "fcfs"]),
    CommandSpec("basic_sjf", "tests/basic.json", ["--policy", "sjf"]),
    CommandSpec("basic_rr", "tests/basic.json", ["--policy", "rr", "--quantum", "2"]),
    CommandSpec("basic_cfs", "tests/basic.json", ["--policy", "cfs", "--slice", "2"]),
    CommandSpec("basic_predicted", "tests/basic.json", ["--policy", "predicted_sjf", "--sigma", "0.0"]),
    CommandSpec("basic_oracle", "tests/basic.json", ["--policy", "oracle_sjf"]),
    CommandSpec("demo_fcfs", "tests/demo.json", ["--policy", "fcfs", "--print-timeline"]),
    CommandSpec("demo_cfs", "tests/demo.json", ["--policy", "cfs", "--slice", "2", "--print-timeline"]),
    CommandSpec("demo_predicted", "tests/demo.json", ["--policy", "predicted_sjf", "--sigma", "0.35", "--seed", "42"]),
]


class VerificationError(Exception):
    pass


def run_command(spec: CommandSpec) -> Dict[str, object]:
    cmd = [PYTHON, "-m", "schedsim", "run", spec.testcase, "--format", "json", *spec.args]
    proc = subprocess.run(
        cmd,
        cwd=ROOT,
        capture_output=True,
        text=True,
    )
    stdout = proc.stdout.strip()
    stderr = proc.stderr.strip()
    if proc.returncode != 0:
        raise VerificationError(
            f"Command '{spec.name}' failed with exit code {proc.returncode}\n"
            f"CMD: {' '.join(cmd)}\nSTDOUT:\n{stdout}\nSTDERR:\n{stderr}"
        )
    try:
        metrics_payload = json.loads(stdout)
    except json.JSONDecodeError as exc:
        raise VerificationError(
            f"Command '{spec.name}' emitted invalid JSON.\nSTDOUT:\n{stdout}\nSTDERR:\n{stderr}"
        ) from exc
    return {
        "spec": spec,
        "cmd": cmd,
        "stdout": stdout,
        "stderr": stderr,
        "payload": metrics_payload,
    }


def workload_stats(path: str) -> Dict[str, float]:
    name, tasks = load_testcase(path)
    max_arrival = max(task.arrival for task in tasks) if tasks else 0
    total_burst = sum(task.burst for task in tasks)
    return {
        "name": name,
        "max_arrival": max_arrival,
        "task_count": len(tasks),
        "total_burst": total_burst,
    }


def assert_condition(condition: bool, message: str) -> None:
    if not condition:
        raise VerificationError(message)


def verify_metrics(result: Dict[str, object], stats: Dict[str, float]) -> None:
    metrics = result["payload"]["metrics"]
    makespan = metrics["makespan"]
    assert_condition(
        makespan >= stats["max_arrival"] + 1,
        f"{result['spec'].name}: makespan {makespan} < max_arrival+1 ({stats['max_arrival'] + 1})",
    )
    for key in ("avg_waiting", "avg_turnaround", "avg_response", "p95_waiting", "p95_turnaround"):
        assert_condition(metrics[key] >= 0, f"{result['spec'].name}: {key} must be >= 0 (got {metrics[key]})")
    assert_condition(
        metrics["avg_turnaround"] + EPS >= metrics["avg_waiting"],
        f"{result['spec'].name}: avg_turnaround < avg_waiting",
    )
    assert_condition(
        metrics["dispatches"] + EPS >= stats["task_count"],
        f"{result['spec'].name}: dispatches {metrics['dispatches']} < task_count {stats['task_count']}",
    )
    assert_condition(
        metrics["makespan"] + EPS >= stats["total_burst"],
        f"{result['spec'].name}: makespan {metrics['makespan']} shorter than total burst {stats['total_burst']}",
    )


def run_micro_test() -> None:
    base_tasks = [
        Task(pid="M1", arrival=0, burst=3),
        Task(pid="M2", arrival=1, burst=2),
        Task(pid="M3", arrival=2, burst=4),
    ]
    tasks = [Task.from_spec(task.pid, task.arrival, task.burst) for task in base_tasks]
    policy = FirstComeFirstServe()
    completed, dispatches, makespan, _ = simulate(tasks, policy)
    assert_condition(dispatches >= len(completed), "micro_test: insufficient dispatches recorded")
    max_finish = 0.0
    for task in completed:
        assert_condition(task.start is not None, f"micro_test: task {task.pid} missing start time")
        assert_condition(task.finish is not None, f"micro_test: task {task.pid} missing finish time")
        assert_condition(task.start + EPS >= task.arrival, f"micro_test: start precedes arrival for {task.pid}")
        assert_condition(task.finish + EPS >= task.start, f"micro_test: finish precedes start for {task.pid}")
        turnaround = task.finish - task.arrival
        assert_condition(turnaround + EPS >= task.burst, f"micro_test: turnaround < burst for {task.pid}")
        max_finish = max(max_finish, task.finish)
    assert_condition(makespan + EPS >= max_finish, "micro_test: makespan shorter than last finish")


def compare_rr_vs_fcfs(results: Dict[str, Dict[str, object]]) -> None:
    rr = results["basic_rr"]["payload"]["metrics"]["dispatches"]
    fcfs = results["basic_fcfs"]["payload"]["metrics"]["dispatches"]
    assert_condition(rr + EPS >= fcfs, f"Round Robin dispatches {rr} < FCFS {fcfs}")


def compare_predicted_vs_oracle(results: Dict[str, Dict[str, object]]) -> None:
    predicted = results["basic_predicted"]["payload"]["metrics"]
    oracle = results["basic_oracle"]["payload"]["metrics"]
    for key in ("avg_waiting", "avg_turnaround"):
        assert_condition(
            abs(predicted[key] - oracle[key]) <= EPS,
            f"predicted_sjf mismatch for {key}: {predicted[key]} vs {oracle[key]}",
        )


def main() -> int:
    try:
        run_micro_test()
        results: Dict[str, Dict[str, object]] = {}
        stats_cache: Dict[str, Dict[str, float]] = {}
        for spec in COMMAND_SPECS:
            stats_cache.setdefault(spec.testcase, workload_stats(spec.testcase))
            result = run_command(spec)
            verify_metrics(result, stats_cache[spec.testcase])
            results[spec.name] = result
        compare_rr_vs_fcfs(results)
        compare_predicted_vs_oracle(results)
    except VerificationError as exc:
        print("FAILED")
        print(exc)
        return 1
    print("DEMO READY")
    return 0


if __name__ == "__main__":
    sys.exit(main())
